<?php

namespace App\Repository;

class ThreadFileRepository
{

}
