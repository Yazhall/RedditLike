<?php

namespace App\Service;

class MathService
{
    public function div(int $a, int $b): int
    {
        return $a / $b;
    }
}
